const jwt = require('jsonwebtoken');
const { passport, enabled } = require('../config/passport');

const allowedOrigins = () =>
  (process.env.CLIENT_URL || 'http://localhost:5173').split(',').map((s) => s.trim());
const safeOrigin = (candidate) => (allowedOrigins().includes(candidate) ? candidate : allowedOrigins()[0]);

const notConfigured = (res, p) =>
  res.status(404).json({ message: `El proveedor "${p}" no está configurado en el servidor.` });

// GET /api/auth/providers -> qué botones sociales mostrar
exports.providers = (req, res) => {
  res.json({ providers: Object.entries(enabled).map(([id, v]) => ({ id, label: v.label })) });
};

// GET /api/auth/:provider?redirect=<origen del frontend>
exports.start = (req, res, next) => {
  const p = req.params.provider;
  if (!enabled[p]) return notConfigured(res, p);
  // El origen del frontend viaja en `state` para volver al front correcto (v1 o v2).
  const state = Buffer.from(safeOrigin(req.query.redirect)).toString('base64url');
  passport.authenticate(p, { session: false, scope: enabled[p].scope, state })(req, res, next);
};

// GET /api/auth/:provider/callback
exports.callback = (req, res, next) => {
  const p = req.params.provider;
  if (!enabled[p]) return notConfigured(res, p);

  let origin = allowedOrigins()[0];
  try {
    origin = safeOrigin(Buffer.from(String(req.query.state || ''), 'base64url').toString());
  } catch { /* usa el origen por defecto */ }

  passport.authenticate(p, { session: false }, (err, user, info) => {
    if (err || !user) {
      if (err && !err.code) console.error(`[oauth:${p}]`, err.message);
      const code = err?.code || info?.message || req.query.error || 'oauth_failed';
      return res.redirect(`${origin}/login?error=${encodeURIComponent(code)}`);
    }
    const token = jwt.sign({ sub: user.id, email: user.email }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    });
    // El token va en el fragmento (#): no viaja al servidor ni queda en logs.
    res.redirect(`${origin}/oauth/callback#token=${token}`);
  })(req, res, next);
};
