const MESSAGES = {
  access_denied: 'Cancelaste el inicio de sesión con el proveedor.',
  email_in_use: 'Ya existe una cuenta con ese email. Entrá con tu contraseña y vinculá el proveedor desde tu cuenta de correo verificada.',
  no_email: 'El proveedor no compartió tu email. Revisá los permisos e intentá de nuevo.',
  oauth_failed: 'No se pudo completar el inicio de sesión. Intentá de nuevo.',
};

export const oauthErrorMessage = (code) => (code ? MESSAGES[code] || MESSAGES.oauth_failed : '');
