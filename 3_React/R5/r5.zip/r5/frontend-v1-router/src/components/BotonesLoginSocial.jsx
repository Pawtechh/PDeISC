import { useEffect, useState } from 'react';
import { API_URL } from '../api/axios';

const ICONS = {
  google: (
    <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
    </svg>
  ),
  github: (
    <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
      <path fill="#111827" d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.202-.007-.75-.012-1.465-3.337.724-4.042-1.61-4.042-1.61-.546-1.385-1.335-1.755-1.335-1.755-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
    </svg>
  ),
  discord: (
    <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
      <path fill="#5865F2" d="M7 5c1.6-.6 3.3-.9 5-.9s3.4.3 5 .9c1.8 2.6 2.9 5.5 3.2 9.2-1.4 1.1-2.9 1.9-4.5 2.4l-.9-1.4c.5-.2 1-.4 1.5-.8-2.5 1.2-5.8 1.2-8.6 0 .5.4 1 .6 1.5.8l-.9 1.4c-1.6-.5-3.1-1.3-4.5-2.4C4.1 10.5 5.2 7.600 7 5z" />
      <circle cx="9.200" cy="12" r="1.300" fill="#fff" />
      <circle cx="14.800" cy="12" r="1.300" fill="#fff" />
    </svg>
  ),
};

// Pide al backend qué proveedores están configurados (fetch nativo) y muestra un botón por cada uno.
export default function BotonesLoginSocial({ verbo = 'Continuar' }) {
  const [providers, setProviders] = useState(null);
  const [offline, setOffline] = useState(false);

  useEffect(() => {
    const ctrl = new AbortController();
    fetch(`${API_URL}/auth/providers`, { signal: ctrl.signal })
      .then((r) => r.json())
      .then((d) => setProviders(d.providers || []))
      .catch((e) => { if (e.name !== 'AbortError') setOffline(true); });
    return () => ctrl.abort();
  }, []);

  const go = (id) => {
    const redirect = encodeURIComponent(window.location.origin);
    window.location.href = `${API_URL}/auth/${id}?redirect=${redirect}`;
  };

  if (offline) return <p className="muted center">No se pudo conectar con el servidor para cargar el ingreso social.</p>;
  if (!providers) return <div className="social"><div className="social-skeleton" /><div className="social-skeleton" /></div>;
  if (providers.length === 0) return null;

  return (
    <div className="social">
      {providers.map((p) => (
        <button key={p.id} type="button" className="social-btn" onClick={() => go(p.id)}>
          <span className="social-icon">{ICONS[p.id]}</span>
          <span>{verbo} con {p.label}</span>
        </button>
      ))}
    </div>
  );
}
