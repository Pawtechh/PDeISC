$feEnv = "VITE_API_URL=http://localhost:4000/api"
$feEnv | Set-Content -Encoding UTF8 .\frontend-v1-router\.env.example
$feEnv | Set-Content -Encoding UTF8 .\frontend-v1-router\.env